# Major > 2022-10-23 5:42pm
https://universe.roboflow.com/object-detection/major-cvqrz

Provided by Roboflow
License: CC BY 4.0

